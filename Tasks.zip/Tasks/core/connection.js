
const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize("etheriumDB", "root", "admin@123", {
  host: 'localhost',
  dialect: "mysql",
  port: 3306
});

const dbConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('Connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

dbConnection();

const db = {};

db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.user = require("../models/userModel")(db.sequelize, db.Sequelize);
db.wallet = require("../models/walletModel")(db.sequelize, db.Sequelize);
db.coin = require("../models/coinModel")(db.sequelize, db.Sequelize);

db.user.hasMany(db.wallet, { foreignKey: "userId" });
db.wallet.belongsTo(db.user, { foreignKey: "userId" });

db.coin.hasMany(db.wallet, { foreignKey: "coinId" });

db.wallet.belongsTo(db.coin, { foreignKey: "coinId" });


// db.user.hasMany(db.wallet, { foreignKey: "userId" });
// db.wallet.belongsTo(db.user, { foreignKey: "userId" });

// db.coin.belongsTo(db.wallet, { foreignKey: "coinId" });
// db.wallet.hasOne(db.coin, { foreignKey: "coinId" });



module.exports = db;



