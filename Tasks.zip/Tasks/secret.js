1.0xDCa816fE9d1263654E63b4ECBe03387cc2123954 =1
2."0x646B5527Cb1D94e993C5c5C62CF316C19A20F7B1" =2
3."0x647595535c370F6092C6daE9D05a7Ce9A8819F37"  =2
4."0xb93cba7013f4557cDFB590fD152d24Ef4063485f" =3
5."0xb3A16C2B68BBB0111EbD27871a5934b949837D95"=2
6.0x4f7A67464B5976d7547c860109e4432d50AfB38e=4
7.0x316A61D381299E29843fA332e84d40F650f54142=5




address
1.0xc16BCF27A4Cc6DfFAbE41D2dE1dE3fE8c2f80a2d


mong_2=1
Uniswap v2=2 // contract 
Dai Stablecoin=3// contract
Native Goerli ETH=4, // satndard web3 methods 
Quantized YearnStrateg=5

can u tell me different methods of web3 for these with example 





//accounts
[
    {
      address: '0x52de9dC7E956754669253401958F66A772B2859B',
      privateKey: '0x297fb73813a7fff9bd0260c08034db11d0f61c7b20e5e866398a5bd0bd4f3c48',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x475e615D678F10aD591ccfB4bAa94Ed82c68EA99',
      privateKey: '0x4f96772bdbf89c21cc0993bd765c61b30d6d18147026f6d576ed435b0569852c',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x96acdfc4393c72bB4F9E6427a5BB0B10b51b5Da5',
      privateKey: '0x7bd9ce80fca52dd47227419a6e5e22f17783c6bd13a118c1af0c55da4b34bd37',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0xc24f82d7985b095613A7596b80383BF0f2C62c0F',
      privateKey: '0x6a5a1b0526ea2cb556ce8e027eb90c953591c4ddc3bd0d87d36512b09c7aba15',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x6afEf224cE5212576FafaABF942Ec05fE4B18A7a',
      privateKey: '0x140ff3e6b4835c443290cb25a321aebdc50da2973dd9c9dc81336812d960e998',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    }
  ]


 
  [
    {
      address: '0xE0A92c08BBAF6df0DF30406DDC7666A6dA8112D1',
      privateKey: '0xdbfca6a2ae9838d892e647151a67a8e6250eb565b50eeb9e227d175df81da9c2',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0xbc1b9089c78f368718996d9Bb65f68d115e93923',
      privateKey: '0x2e8621d28245132d1e603574576e3f3b25882723cc0e786ca6adb59566c733f7',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x708a909277364b7D3c6337FEE147Da2ee12FAeCB',
      privateKey: '0xd237795b7842eb70f6ec82e392e2c24cad93c11a020e8a2c976d78f811a7b029',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x56BB09308CD4e880ec9E0bBc81A407049898d69b',
      privateKey: '0x06e91e2b9d991077739e1fdf90337cd1bca12d2b68d9ab744b4bde45ee6e9dad',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0xA1fEDaD7F83F2AB6d6d171c035b3a8854f9F524C',
      privateKey: '0xdfd902794fb946cc513a9cb33fd26e759d24c7629e2e22fcc960c8ec9f757e72',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    }
  ]

  [
    {
      address: '0x645Af2C481756bdF0b0Ea7Db35Ce7D2a73bB8832',
      privateKey: '0x387f5bb6a7c007e473cfe830356b861b3e6a902c850bd86abf890f6ab38830d5',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x85Aff5C3560620951DD8874099ca2aA19FBc199E',
      privateKey: '0xcb4e5ffa85d3e3e9ea206e0336a429ef1a6bd72e0cd88cce4ecbc92760da323d',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x4C30012E2112761d7239d6070caEFB467DD82c01',
      privateKey: '0x3aca427f5f66ffdf12c746a7e4161421b9fe0af5947acace7d0bd439df9bb22c',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0xdBEC3104CE348d6CBbB25DF3dfDE8bAb9544f49c',
      privateKey: '0xa4d5495b8bb32e288f49d70100103d96402abe1485babb0d13a50c5344985d0f',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    },
    {
      address: '0x1022D5FaAB71a916fc1F441efe1816DF0861d908',
      privateKey: '0x50198b6ed78c9f7081f7fb0dd7162eac94d85ff18a9f2945a26ef57ecdbdf7c5',
      signTransaction: [Function: signTransaction],
      sign: [Function: sign],
      encrypt: [Function: encrypt]
    }
  ]