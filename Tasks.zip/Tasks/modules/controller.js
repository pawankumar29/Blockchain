
// //get token from the user
// // will provide name and symbol
// // add that coin in the wallet
// // and show that to the user
// // write all code in sequellize and make wallet app

const web3 = require("web3");
const constant = require("../core/constant");
const db = require("../core/connection");
const url = "https://goerli.infura.io/v3/ddb43e80c00c475bbf4f3f80bb41a932";

const web3Instance = new web3(url);


class wallet {
  createCoin = async (req, res) => {
    try {
      const { tokenAddress, coinFamily } = req.body;
      const contract = new web3Instance.eth.Contract(constant.abi, tokenAddress);
      const name = await contract.methods.name().call();
      const symbol = await contract.methods.symbol().call();
      const decimal = await contract.methods.decimals().call();
      const decimalFormatted = `1e${decimal}`;
      const coinObject = {
        name: name,
        symbol: symbol,
        decimal: decimalFormatted,
        tokenAddress: tokenAddress,
        coinFamily: coinFamily
      }
      console.log(coinObject)
      const result = await db.coin.create(coinObject);

      res.status(200).json({ status: 1, message: "successful", data: result })

    } catch (error) {
      res.status(400).json({ status: 0, message: error.message });

    }

  }

  createWallet = async (req, res) => {
    try {

      const array = req.body;


    const promiseArray=  array.map(async (item) => {
        const coinSearch = await db.coin.findOne({ where: { name: item.coinName, symbol: item.coinSymbol } })
  //  const coinSearch = await db.coin.findOne({ where: {} })

    console.log("c--->",coinSearch);

        const WalletExistAlready = await db.wallet.findOne({ where: { wallet_address: item.walletAddress, coinId: coinSearch.coinId } });

        if (!WalletExistAlready) {

const balance=await web3Instance.eth.getBalance(item.walletAddress);
          const walletObject = {
            userId: item.userId,
            wallet_address: item.walletAddress,
            coinId:coinSearch.coinId,
            balance:balance,
            coinFamily:coinSearch.coinFamily
          }

          return db.wallet.create(walletObject);
        }




      })

      await Promise.all(promiseArray);
      res.status(200).json({status:1,message:"successful",})

    } catch (error) {
      res.status(400).json({status:0,message:error.message})
    }
  }

  coinList = async (req, res) => {
    try {
      const walletAddress = req.params.walletAddress;
  
      const result = await db.wallet.findAll({
        where: {
          wallet_address: walletAddress,
        },
        include: {
          model: db.coin,
          attributes: ['name', 'symbol'],
        },

        attributes:["walletId","userId","wallet_address"]
      });
  
      res.status(200).json({ status: 1, message: 'successful', data: result });
    } catch (error) {
      res.status(400).json({ status: 0, message: error.message });
    }
  };

  fetchBalance = async (req, res) => {
    try {
      const  address = req.params.walletAddress;
  
      const wallet = await db.wallet.findOne({
        where: {
          wallet_address: address,
        },
        include: [
          {
            model: db.coin,
            attributes: ["coinFamily", "tokenAddress"],
          },
        ],
     
      });

      let balance;
          const coinFamily=wallet.coinFamily;
          const token=wallet.coin.tokenAddress;
            switch (coinFamily) {   // eth:1,uni:2,dai:3
              case 1:
                balance = await web3.eth.getBalance(address);
                break;
              case 2:
                
                const uniContractAddress = token ; 
                const uniTokenAbi = constant.uniTokenAbi; 
                const uniContractInstance = new web3Instance.eth.Contract(uniTokenAbi, uniContractAddress);
                balance = await uniContractInstance.methods.balanceOf(address).call();
                break;
              case 3:
                const daiContractAddress = token; 
                const daiTokenAbi = constant.daiTokenAbi; 
                const daiContractInstance = new web3Instance.eth.Contract(daiTokenAbi, daiContractAddress);
                balance = await daiContractInstance.methods.balanceOf(address).call();
                break;
              
              default:
                return res.status(400).json({ message: 'Invalid token' });
            }


  
      res.status(200).json({status:1,data:balance});
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  };
  
  searchToken=async(req,res)=>{
    try {
      const tokenAddress=req.params.tokenAddress;
      const contract = new web3Instance.eth.Contract(constant.abi, tokenAddress);
      const name = await contract.methods.name().call();
      const symbol = await contract.methods.symbol().call();

      const data={
          name:name,
          symbol:symbol,
        
      }

       if(contract&&name&&symbol)
      res.status(200).json({status:1,message:"token Is valid ",data:data});
      else
      throw new Error("Not vslid Token ")
      
    } catch (error) {
      res.status(400).json({ status: 0, message: error.message });

    }
   
  }
}

module.exports = new wallet();





