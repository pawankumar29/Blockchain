const express=require("express");
const app=express();

const db=require("./core/connection");
const router = require("./modules/router");


app.use(express.json());
app.use(router);

db.sequelize.sync();
app.listen(3000,()=>{
     console.log(`app is running at port:3000`);
})



//https://goerli.etherscan.io/address/0x1264f1d2679cb4a648f8555e910fa14e3397987a#code


