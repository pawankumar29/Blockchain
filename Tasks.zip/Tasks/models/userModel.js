
module.exports=(sequelize,Sequelize)=>{

   const user=sequelize.define("user",{
    
        userId:{
            type:Sequelize.INTEGER,
            allowNull:false,
            primaryKey:true,
        
        }


   },{
    timestamps:false
   })


return user;


}