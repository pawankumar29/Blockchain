
module.exports=(sequelize,Sequelize)=>{

    const coin=sequelize.define("coin",{
         name:{
             type:Sequelize.STRING,
             allowNull:false
         },
         symbol:{
             type:Sequelize.STRING,
             allowNull:false,
            
         },
         coinId:{
            type:Sequelize.INTEGER,       // single copy different tokens 
            allowNull:false,
            primaryKey:true,
            autoIncrement:true,
         },

        tokenAddress:{
            type:Sequelize.STRING

        },
        decimal:{
            type:Sequelize.STRING
        },
        coinFamily:{
            type:Sequelize.INTEGER
        },
        
    },{    timestamps:false
    })
 
 
 return coin;
 
 
 }