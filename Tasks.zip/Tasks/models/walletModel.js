
module.exports=(sequelize,Sequelize)=>{

    const wallet=sequelize.define("wallet",{
      
         
         walletId:{
            type:Sequelize.INTEGER,
            allowNull:false,
            primaryKey:true,
            autoIncrement:true
         },
         wallet_address:{
            type:Sequelize.STRING

         },
       
        balance:{
            type:Sequelize.STRING
        },
        coinId:{
            type:Sequelize.INTEGER,
            
            
        },
        userId:{
            type:Sequelize.INTEGER

        },
        coinFamily:{
            type:Sequelize.INTEGER
        }
           
       
    },{    timestamps:false
    })
 
 
 return wallet;
 
 
 }