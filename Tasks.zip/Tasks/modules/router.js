const express=require("express");
const wallet = require("./controller");
const router=express.Router();


router.route("/createCoin").post(wallet.createCoin);
router.route("/createWallet").post(wallet.createWallet);
router.route("/coinList/:walletAddress").get(wallet.coinList);
router.route("/searchToken/:tokenAddress").get(wallet.searchToken);
router.route("/fetchBalance/:walletAddress").get(wallet.fetchBalance);






module.exports=router;